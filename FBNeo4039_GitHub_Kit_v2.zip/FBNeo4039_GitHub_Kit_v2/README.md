# FBNeo 4039 Android build kit

Contains the FBNeo 4039 Capcom-driver overlay and a GitHub Actions workflow. No ROMs are included.
