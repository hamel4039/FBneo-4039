# FBNeo 4039 Android ARM64 build kit

The workflow checks out official libretro/FBNeo, applies the 4039 Capcom overlay, and builds the Libretro core for Android ARM64 using the Android NDK.

The workflow file must be uploaded to `.github/workflows/android.yml` in the repository root. The overlay files go under `overlay/src/burn/drv/capcom/`.

No ROMs are included.
