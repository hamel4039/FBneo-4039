// FBNeo 4039 - Marvel vs. Capcom expansion hooks
// Phase 1: virtual Kael Character Select slot.

#include "burnint.h"
#include "cps.h"
#include "cps2_4039.h"
#include <string.h>

static bool IsMvsc4039()
{
	const TCHAR* name = BurnDrvGetText(DRV_NAME);
	return name && (_tcscmp(name, _T("mvsc")) == 0);
}

// MvC1 work-RAM cursor positions documented by the reverse-engineering pass.
static constexpr UINT32 KAEL_P1_CURSOR = 0x2000;
static constexpr UINT32 KAEL_P2_CURSOR = 0x2002;
static constexpr UINT16 WOLVERINE_POS = 5;
static constexpr INT32 KAEL_X = 352;
static constexpr INT32 KAEL_Y = 192;
static constexpr INT32 KAEL_W = 32;
static constexpr INT32 KAEL_H = 32;

static bool sKaelVirtualP1 = false;
static bool sKaelVirtualP2 = false;
static UINT8 sPrevP1 = 0;
static UINT8 sPrevP2 = 0;
static UINT8 sPrevP1Fire = 0;
static UINT8 sPrevP2Fire = 0;
static UINT8 sPrevP1Char = 0xff;
static UINT8 sPrevP2Char = 0xff;
static UINT8 sCharStableP1 = 0xff;
static UINT8 sCharStableP2 = 0xff;

static UINT16 ReadRamWord(UINT32 offset)
{
	return (UINT16)((CpsRamFF[offset] << 8) | CpsRamFF[offset + 1]);
}

static void WriteRamWord(UINT32 offset, UINT16 value)
{
	CpsRamFF[offset + 0] = (UINT8)(value >> 8);
	CpsRamFF[offset + 1] = (UINT8)(value & 0xff);
}

static UINT8 ReadRamByte(UINT32 offset)
{
	return CpsRamFF[offset];
}

static bool CharacterSelectWindow(UINT8 current, UINT8& previous, UINT8& stable)
{
	if (current != previous) {
		previous = current;
		stable = 0;
		return true;
	}

	if (stable < 60) stable++;
	return stable < 60;
}

void Cps4039Reset()
{
	sKaelVirtualP1 = false;
	sKaelVirtualP2 = false;
	sPrevP1 = 0;
	sPrevP2 = 0;
	sPrevP1Fire = 0;
	sPrevP2Fire = 0;
	sPrevP1Char = 0xff;
	sPrevP2Char = 0xff;
	sCharStableP1 = 0xff;
	sCharStableP2 = 0xff;
}

void Cps4039FrameStart()
{
	if (!IsMvsc4039()) return;

	const UINT8 p1 = CpsInp001[0];
	const UINT8 p2 = CpsInp000[0];
	const bool p1RightEdge = (p1 != 0) && (sPrevP1 == 0);
	const bool p2RightEdge = (p2 != 0) && (sPrevP2 == 0);
	const bool p1LeftEdge = (CpsInp001[1] != 0);
	const bool p2LeftEdge = (CpsInp000[1] != 0);
	const UINT8 p1Fire = (UINT8)(CpsInp001[4] | CpsInp001[5] | CpsInp001[6]);
	const UINT8 p2Fire = (UINT8)(CpsInp000[4] | CpsInp000[5] | CpsInp000[6]);
	const bool p1FireEdge = (p1Fire != 0) && (sPrevP1Fire == 0);
	const bool p2FireEdge = (p2Fire != 0) && (sPrevP2Fire == 0);

	const UINT8 p1Char = ReadRamByte(0x3053);
	const UINT8 p2Char = ReadRamByte(0x3153);
	const bool p1SelectWindow = CharacterSelectWindow(p1Char, sPrevP1Char, sCharStableP1);
	const bool p2SelectWindow = CharacterSelectWindow(p2Char, sPrevP2Char, sCharStableP2);

	// Wolverine is character ID $08 and logical cursor position 5.  The
	// 60-frame character-change window prevents this hook from firing during
	// a fight, where the selected character ID remains stable.
	if (!sKaelVirtualP1 && p1SelectWindow && p1Char == 0x08 &&
		ReadRamWord(KAEL_P1_CURSOR) == WOLVERINE_POS && p1RightEdge) {
		sKaelVirtualP1 = true;
	}
	if (!sKaelVirtualP2 && p2SelectWindow && p2Char == 0x08 &&
		ReadRamWord(KAEL_P2_CURSOR) == WOLVERINE_POS && p2RightEdge) {
		sKaelVirtualP2 = true;
	}

	// Left returns from the virtual cell to the normal Wolverine cell.
	if (sKaelVirtualP1 && p1LeftEdge) sKaelVirtualP1 = false;
	if (sKaelVirtualP2 && p2LeftEdge) sKaelVirtualP2 = false;

	// Confirming the virtual cell currently commits Wolverine as a safe
	// diagnostic placeholder. This proves the complete select -> confirm
	// path without handing an unsupported character ID to the stock game.
	// The placeholder ID will be replaced when Kael's actual character slot
	// is installed.
	if (sKaelVirtualP1 && p1FireEdge) {
		CpsRamFF[0x3053] = 0x08;
		sKaelVirtualP1 = false;
	}
	if (sKaelVirtualP2 && p2FireEdge) {
		CpsRamFF[0x3153] = 0x08;
		sKaelVirtualP2 = false;
	}

	// Keep the stock logical cursor on Wolverine while our custom cell is
	// active. This prevents the original navigation tables from indexing
	// beyond their native range.
	if (sKaelVirtualP1) WriteRamWord(KAEL_P1_CURSOR, WOLVERINE_POS);
	if (sKaelVirtualP2) WriteRamWord(KAEL_P2_CURSOR, WOLVERINE_POS);

	sPrevP1 = p1;
	sPrevP2 = p2;
	sPrevP1Fire = p1Fire;
	sPrevP2Fire = p2Fire;
}

static void DrawKaelSlotOutline()
{
	if (!pBurnDraw) return;

	if (nBurnBpp == 2) {
		const UINT16 pixel = 0xffff;
		for (INT32 yy = 0; yy < KAEL_H; yy++) {
			UINT16* row = (UINT16*)(pBurnDraw + yy * nBurnPitch) + KAEL_X;
			for (INT32 xx = 0; xx < KAEL_W; xx++) {
				if (yy == 0 || yy == KAEL_H - 1 || xx == 0 || xx == KAEL_W - 1)
					row[xx] = pixel;
			}
		}
	} else if (nBurnBpp == 4) {
		const UINT32 pixel = 0xffffffff;
		for (INT32 yy = 0; yy < KAEL_H; yy++) {
			UINT32* row = (UINT32*)(pBurnDraw + yy * nBurnPitch) + KAEL_X;
			for (INT32 xx = 0; xx < KAEL_W; xx++) {
				if (yy == 0 || yy == KAEL_H - 1 || xx == 0 || xx == KAEL_W - 1)
					row[xx] = pixel;
			}
		}
	}
}

void Cps4039CharacterSelectDraw()
{
	if (!pBurnDraw || !IsMvsc4039()) return;

	// Only expose the diagnostic cell after the virtual navigation state has
	// been entered. This prevents the marker from appearing during gameplay.
	if (sKaelVirtualP1 || sKaelVirtualP2) {
		DrawKaelSlotOutline();
	}
}

bool Cps4039KaelVirtualP1() { return sKaelVirtualP1; }
bool Cps4039KaelVirtualP2() { return sKaelVirtualP2; }
