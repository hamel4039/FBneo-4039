// FBNeo 4039 - Marvel vs. Capcom expansion hooks
#pragma once

void Cps4039Reset();
void Cps4039FrameStart();
void Cps4039CharacterSelectDraw();
bool Cps4039KaelVirtualP1();
bool Cps4039KaelVirtualP2();
