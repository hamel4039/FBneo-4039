# FBNeo 4039 - GitHub build kit

Este pacote contém apenas as alterações do projeto FBNeo 4039 e um workflow para preparar uma compilação Android/Libretro.

## Importante

O pacote NÃO contém ROMs. A ROM modificada deve continuar separada.

O workflow baixa o repositório Libretro/FBNeo e aplica as alterações 4039 antes de compilar. A receita Android oficial do libretro-super identifica o FBNeo como um core Android baseado em Makefile, com `src/burner/libretro/jni` como diretório JNI.

## Arquivos

- `patch/src/burn/drv/capcom/cps2_4039.cpp`
- `patch/src/burn/drv/capcom/cps2_4039.h`
- `patch/cps_run.patch`
- `patch/cps_draw.patch`
- `patch/meson.patch`
- `.github/workflows/android.yml`

## Uso

Envie o conteúdo deste kit para o repositório GitHub `FBNeo-4039`. Depois abra a aba Actions e execute `Build FBNeo 4039 Android`.

O objetivo do workflow é gerar um core Libretro Android ARM64 como artefato. O core só deve ser considerado pronto depois que o build terminar sem erros e o arquivo gerado for testado no RetroArch.
